package edu.ncsu.csc216.pack_scheduler.user;

public class Student {

	public Student(String firstName, String lastName, String id, String email, String hashPW, int maxCredits) {
		// TODO Auto-generated constructor stub
	}
	
	public Student(String firstName, String lastName, String id, String email, String hashPW) {
		// TODO Auto-generated constructor stub
	}
	
	public String getFirstName() {
		// TODO Auto-generated method stub
		return null;
	}

	public String getLastName() {
		// TODO Auto-generated method stub
		return null;
	}
	
	public String getId() {
		// TODO Auto-generated method stub
		return null;
	}

}
