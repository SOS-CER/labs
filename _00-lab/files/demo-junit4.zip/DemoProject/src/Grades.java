import java.util.Arrays;

/**
 * Represents the grades of a CSC 216 student.
 * Grades for CSC 217 are an average of the labs.  
 * CSC 216 grades are more interesting to calculate.
 * @author Dr. Sarah Heckman
 */
public class Grades {
	
	/** GP1 grade */
	private double gp1;
	/** GP2 grade */
	private double gp2;
	/** GP3 grade */
	private double gp3;
	/** P1P1 grade */
	private double p1p1;
	/** P1P2 grade */
	private double p1p2;
	/** P2P1 grade */
	private double p2p1;
	/** P2P2 grade */
	private double p2p2;
	/** Quiz grades*/
	private double [] quizzes;
	/** Index to add quiz grades at */
	private int idx;
	
	/** Percent of Guided Project average in final grade */
	private static final int GP_PERCENT = 16;
	/** Percent of Part 1 in project grade */
	private static final int PART1_PERCENT = 20;
	/** Percent of Part 2 in project grade */
	private static final int PART2_PERCENT = 80;
	/** Percent of Project average in final grade */
	private static final int PROJECTS_PERCENT = 44;
	/** Number of quizzes in the semester */
	public static final int NUM_QUIZZES = 14;
	/** Percent of Quiz average in final grade */
	private static final int QUIZZES_PERCENT = 40;
	/** Threshold for first level of MGR */
	private static final int FIRST_MGR_THRESHOLD = 60;
	/** Threshold for second level of MGR */
	private static final int SECOND_MGR_THRESHOLD = 65;
	/** Highest possible grade for MGR if earning a letter grade */
	private static final int HIGHEST_MGR_GRADE = 72;
	/** Grade cutoff for D-*/
	private static final int D_MINUS = 60;
	/** Grade cutoff for D*/
	private static final int D = 63;
	/** Grade cutoff for D+*/
	private static final int D_PLUS = 67;
	/** Grade cutoff for C-*/
	private static final int C_MINUS = 70;
	/** Grade cutoff for C-*/
	private static final int C = 73;
	/** Grade cutoff for C+*/
	private static final int C_PLUS = 77;
	/** Grade cutoff for B-*/
	private static final int B_MINUS = 80;
	/** Grade cutoff for B*/
	private static final int B = 83;
	/** Grade cutoff for B+*/
	private static final int B_PLUS = 87;
	/** Grade cutoff for A-*/
	private static final int A_MINUS = 90;
	/** Grade cutoff for A*/
	private static final int A = 93;
	/** Grade cutoff for A+*/
	private static final int A_PLUS = 97;
	/** Full score in CSC 216*/
	private static final int FULL_SCORE = 100;
	
	/**
	 * Constructs the Grade object and creates the quiz array.
	 */
	public Grades() {
	    quizzes = new double[NUM_QUIZZES];
	}

	/**
	 * Returns the final numerical grade for the course.
	 */
	public double getFinalGrade() {
		double grade = ((getGuidedProjectsAverage() * GP_PERCENT) + 
		        (getProjectsAverage() * PROJECTS_PERCENT) + 
		        (getQuizAverage() * QUIZZES_PERCENT)) / FULL_SCORE;
				
		return grade;
	}
	
	/**
	 * Returns the guided projects average grade.
	 * @return guided projects average grade
	 */
	public double getGuidedProjectsAverage() {
	    return ((gp1 + gp2 + ((gp3 / 115) * 100)) / 3);
	}
	
	/**
     * Returns the projects average grade.
     * @return projects average grade
     */
    public double getProjectsAverage() {
        double project1 = ((p1p1 * PART1_PERCENT) + (p1p2 * PART2_PERCENT)) / 100;
        double project2 = ((p2p1 * PART1_PERCENT) + (p2p2 * PART2_PERCENT)) / 100;
        return (project1 + project2) / 2;
    }
    
    /**
     * Returns the quiz average grades that are available.
     * @return quiz average grade
     */
    public double getQuizAverage() {
        double sum = 0;
        for (int i = 0; i < idx; i++) {
            sum += quizzes[i];
        }
        
        return sum / quizzes.length;
    }
	
	/**
	 * Returns the letter grade for CSC216 by considering the minimum grade requirements (MGR)
	 * and grade calculation.
	 * @return letter grade for CSC216
	 */
	public String getFinalLetterGrade() {
		double grade = getFinalGrade();
		double projectMGR = getProjectMGR();
		double projectGPMGR = getProjectGPMGR();
		double examMGR = getQuizMGR();
		
		if (projectMGR < FIRST_MGR_THRESHOLD || examMGR < FIRST_MGR_THRESHOLD) {
			return "F";
		}
		
		if (projectGPMGR < SECOND_MGR_THRESHOLD || examMGR < SECOND_MGR_THRESHOLD) {
			grade =  Math.min(HIGHEST_MGR_GRADE, grade);
		}
		
		if (grade >= A_PLUS) return "A+";
		if (grade >= A) return "A";
		if (grade >= A_MINUS) return "A-";
		if (grade >= B_PLUS) return "B+";
		if (grade >= B) return "B+";
		if (grade >= B_MINUS) return "B-";
		if (grade >= C_PLUS) return "C+";
		if (grade >= C) return "C";
		if (grade >= C_MINUS) return "C-";
		if (grade >= D_PLUS) return "D+";
		if (grade >= D) return "D";
		if (grade >= D_MINUS) return "D-";
		if (grade >= 0) return "F";
		return null;
		
	}
	
	/**
	 * Returns the project MGR
	 * @return the project MGR
	 */
	public double getProjectMGR() {
		return getProjectsAverage();
	}
	
	/**
	 * Returns the project and guided project MGR
	 * @return the project and GP MGR
	 */
	public double getProjectGPMGR() {
		double projectGPMGR = 
				((getGuidedProjectsAverage() * GP_PERCENT) +
				(getProjectsAverage() * PROJECTS_PERCENT))  / 
				(GP_PERCENT + PROJECTS_PERCENT);
		return projectGPMGR;
	}
	
	/**
	 * Returns the quiz MGR 
	 * @return quiz MGR
	 */
	public double getQuizMGR() {
		return getQuizAverage();
	}

	/**
	 * Returns GP1 grade
	 * @return GP1 grade
	 */
	public double getGp1() {
		return gp1;
	}

	/**
	 * Sets GP1 grade
	 * @param gp1 grade
	 */
	public void setGp1(double gp1) {
		this.gp1 = gp1;
	}

	/**
	 * Returns GP2 grade
	 * @return GP2 grade
	 */
	public double getGp2() {
		return gp2;
	}

	/**
	 * Sets GP2 grade
	 * @param gp2 grade
	 */
	public void setGp2(double gp2) {
		this.gp2 = gp2;
	}

	/**
	 * Returns GP3 grade
	 * @return GP3 grade
	 */
	public double getGp3() {
		return gp3;
	}

	/**
	 * Sets GP3 grade
	 * @param gp3 grade
	 */
	public void setGp3(double gp3) {
		this.gp3 = gp3;
	}

	/**
	 * Returns P1P1 grade
	 * @return P1P1 grade
	 */
	public double getP1p1() {
		return p1p1;
	}

	/**
	 * Sets P1P1 grade
	 * @param p1p1 grade
	 */
	public void setP1p1(double p1p1) {
		this.p1p1 = p1p1;
	}

	/**
	 * Returns P1P2 grade
	 * @return P1P2 grade
	 */
	public double getP1p2() {
		return p1p2;
	}

	/**
	 * Sets P1P2 grade
	 * @param p1p2 grade
	 */
	public void setP1p2(double p1p2) {
		this.p1p2 = p1p2;
	}

	/**
	 * Returns P2P1 grade
	 * @return P2P1 grade
	 */
	public double getP2p1() {
		return p2p1;
	}
	/**
	 * Sets P2P1 grade
	 * @param p2p1 grade
	 */
	public void setP2p1(double p2p1) {
		this.p2p1 = p2p1;
	}

	/**
	 * Returns P2P2 grade
	 * @return P2P2 grade
	 */
	public double getP2p2() {
		return p2p2;
	}
	/**
	 * Sets P2P2 grade
	 * @param p2p2 grade
	 */
	public void setP2p2(double p2p2) {
		this.p2p2 = p2p2;
	}
	
	/**
	 * Adds a quiz grade. IllegalArgumentException if the array
	 * is full.
	 * @param grade quiz grade to add
	 */
	public void addQuizGrade(double grade) {
	    if (idx < NUM_QUIZZES) {
	        quizzes[idx] = grade;
	        idx++;
	    } else {
	        throw new IllegalArgumentException();
	    }
	}
	
	/**
	 * Compares all of the grade information.
	 * @param obj object to compare to this one
	 * @return true if the grades are the same
	 */
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Grades other = (Grades) obj;
		if (Double.doubleToLongBits(gp1) != Double.doubleToLongBits(other.gp1))
			return false;
		if (Double.doubleToLongBits(gp2) != Double.doubleToLongBits(other.gp2))
			return false;
		if (Double.doubleToLongBits(gp3) != Double.doubleToLongBits(other.gp3))
			return false;
		if (Double.doubleToLongBits(p1p1) != Double.doubleToLongBits(other.p1p1))
			return false;
		if (Double.doubleToLongBits(p1p2) != Double.doubleToLongBits(other.p1p2))
			return false;
		if (Double.doubleToLongBits(p2p1) != Double.doubleToLongBits(other.p2p1))
			return false;
		if (Double.doubleToLongBits(p2p2) != Double.doubleToLongBits(other.p2p2))
			return false;
		return Arrays.equals(quizzes, other.quizzes);
	}
	
	/**
	 * Returns grade info as a String.
	 * @return grade info
	 */
	@Override
	public String toString() {
		String gradeInfo = "";
		gradeInfo += "Project MGR: " + getProjectMGR() + "\n";
		gradeInfo += "Project + GP MGR: " + getProjectGPMGR() + "\n";
		gradeInfo += "Exam MGR: " + getQuizMGR() + "\n";
		gradeInfo += "Final Grade: " + getFinalGrade() + "\n";
		gradeInfo += "Final Letter Grade: " + getFinalLetterGrade();
		return gradeInfo;
	}

}
