import static org.junit.Assert.*;

import org.junit.Before;
import org.junit.Test;

/** 
 * Tests for the Grades class
 * @author Dr. Sarah Heckman
 */
public class GradesTest {
    
    /** A student quiz grades */
    private double[] quizA = {95.2, 94.3, 97.8, 96, 87, 100, 95.1, 86.2, 98, 94, 94.1, 89, 91, 98}; 
    /** B student quiz grades */
    private double[] quizB = {82, 81, 83, 84, 85, 87, 89, 89, 88, 82, 82, 81, 83, 79};
    /** C student quiz grades */
    private double[] quizC = {81, 76, 71, 59, 97, 75, 78, 78, 79, 72, 73, 74, 75, 76};
    /** MGR quiz grades */
    private double[] quizMGR = {56, 23, 17, 98, 12, 57, 48, 32, 45, 54, 65, 71, 23, 0};
	/**
	 * Test A student
	 */
	@Test
	public void testAStudent() {
		Grades studentA = new Grades();
		studentA.setGp1(97);
		studentA.setGp2(94);
		studentA.setGp3(110);
		studentA.setP1p1(95);
		studentA.setP1p2(98);
		studentA.setP2p1(97);
		studentA.setP2p2(94);
		for (int i = 0; i < quizA.length; i++) {
		    studentA.addQuizGrade(quizA[i]);
		}
		assertEquals(95.12, studentA.getFinalGrade(), 0.01);
		assertEquals("A", studentA.getFinalLetterGrade());
		assertEquals(96, studentA.getProjectMGR(), 0.01);
		assertEquals(95.88, studentA.getProjectGPMGR(), 0.01);
		assertEquals(93.97, studentA.getQuizMGR(), 0.01);
	}
	
	/**
	 * Test B student
	 */
	@Test
	public void testBStudent() {
		Grades studentB = new Grades();
		studentB.setGp1(87);
		studentB.setGp2(84);
		studentB.setGp3(97);
		studentB.setP1p1(85);
		studentB.setP1p2(88);
		studentB.setP2p1(87);
		studentB.setP2p2(84);
		for (int i = 0; i < quizB.length; i++) {
            studentB.addQuizGrade(quizB[i]);
        }
		assertEquals(85.03, studentB.getFinalGrade(), 0.01);
		assertEquals("B", studentB.getFinalLetterGrade());
		assertEquals(86, studentB.getProjectMGR(), 0.01);
		assertEquals(85.76, studentB.getProjectGPMGR(), 0.01);
		assertEquals(83.93, studentB.getQuizMGR(), 0.01);
	}
	
	/**
	 * Test C student
	 */
	@Test
	public void testCStudent() {
		Grades studentC = new Grades();
		studentC.setGp1(77);
		studentC.setGp2(74);
		studentC.setGp3(87);
		studentC.setP1p1(75);
		studentC.setP1p2(78);
		studentC.setP2p1(77);
		studentC.setP2p2(74);
		for (int i = 0; i < quizC.length; i++) {
            studentC.addQuizGrade(quizC[i]);
        }
	}
	
	/**
     * Test Quiz MGR student
     */
    @Test
    public void testQuizMGRStudent() {
        Grades studentMGR = new Grades();
        studentMGR.setGp1(87);
        studentMGR.setGp2(84);
        studentMGR.setGp3(97);
        studentMGR.setP1p1(85);
        studentMGR.setP1p2(88);
        studentMGR.setP2p1(87);
        studentMGR.setP2p2(84);
        for (int i = 0; i < quizMGR.length; i++) {
            studentMGR.addQuizGrade(quizMGR[i]);
        }
        assertEquals(68.62, studentMGR.getFinalGrade(), 0.01);
        assertEquals("F", studentMGR.getFinalLetterGrade());
        assertEquals(86, studentMGR.getProjectMGR(), 0.01);
        assertEquals(85.76, studentMGR.getProjectGPMGR(), 0.01);
        assertEquals(42.93, studentMGR.getQuizMGR(), 0.01);
    }
    
    /**
     * Test Project+GP MGR student 
     */
    @Test
    public void testProjectGPMGRStudent() {
        Grades studentMGR = new Grades();
        studentMGR.setGp1(12);
        studentMGR.setGp2(35);
        studentMGR.setGp3(25);
        studentMGR.setP1p1(75);
        studentMGR.setP1p2(78);
        studentMGR.setP2p1(77);
        studentMGR.setP2p2(74);
        for (int i = 0; i < quizA.length; i++) {
            studentMGR.addQuizGrade(quizA[i]);
        }
        assertEquals(74.69, studentMGR.getFinalGrade(), 0.01);
        assertEquals("C-", studentMGR.getFinalLetterGrade());
        assertEquals(76, studentMGR.getProjectMGR(), 0.01);
        assertEquals(61.84, studentMGR.getProjectGPMGR(), 0.01);
        assertEquals(93.97, studentMGR.getQuizMGR(), 0.01);
    }
    
    /**
     * Test Project MGR student
     */
    @Test
    public void testProjectMGRStudent() {
        Grades studentMGR = new Grades();
        studentMGR.setGp1(100);
        studentMGR.setGp2(95);
        studentMGR.setGp3(110);
        studentMGR.setP1p1(54);
        studentMGR.setP1p2(12);
        studentMGR.setP2p1(87);
        studentMGR.setP2p2(56);
        for (int i = 0; i < quizA.length; i++) {
            studentMGR.addQuizGrade(quizA[i]);
        }
        assertEquals(71.26, studentMGR.getFinalGrade(), 0.01);
        assertEquals("F", studentMGR.getFinalLetterGrade());
        assertEquals(41.3, studentMGR.getProjectMGR(), 0.01);
        assertEquals(56.12, studentMGR.getProjectGPMGR(), 0.01);
        assertEquals(93.97, studentMGR.getQuizMGR(), 0.01);
    }
	
}
